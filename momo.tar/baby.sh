#!/bin/bash

while true; do
  echo "𝙾𝙶𝚈𝙰𝙰! 𝙾𝙶𝚈𝙰𝙰!"
  sleep 1
done
